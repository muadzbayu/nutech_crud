<!-- Awal Footer -->
<footer class="container-fluid text-center py-3 bg-light border-top">
    Copyright &copy; 2022 - <span class="text-primary fw-bold">Mu'adz Bayu</span>
</footer>
<!-- Akhir Footer --><?php /**PATH C:\xampp\htdocs\nutech_crud\resources\views/partials/footer.blade.php ENDPATH**/ ?>
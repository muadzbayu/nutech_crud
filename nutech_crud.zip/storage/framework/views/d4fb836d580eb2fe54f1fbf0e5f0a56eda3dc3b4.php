

<?php $__env->startSection('content'); ?>
    <section class="jumbotron text-center">
        <img src="img/bayu.jpg" alt="foto profil" width="200" height="200" class="rounded-circle">
        <h1 class="display-4">Mu'adz Bayu</h1>
        <div style="width:500px; margin:auto">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Nobis natus non dicta nostrum saepe vitae culpa accusantium,
                architecto ab qui eos sapiente! Ipsum nihil at ea. <br>
                Magni ipsa provident voluptatibus. Lorem ipsum dolor sit amet consectetur adipisicing elit.
                Nobis natus non dicta nostrum saepe vitae culpa accusantium,
                architecto ab qui eos sapiente! Ipsum nihil at ea. 
                Magni ipsa provident voluptatibus.</p>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#ffffff" fill-opacity="1" d="M0,32L48,69.3C96,107,192,181,288,202.7C384,224,480,192,576,160C672,128,768,96,864,112C960,128,1056,192,1152,208C1248,224,1344,192,1392,176L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nutech_crud\resources\views/home.blade.php ENDPATH**/ ?>
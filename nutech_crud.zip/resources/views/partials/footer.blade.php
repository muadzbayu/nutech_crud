<!-- Awal Footer -->
<footer class="container-fluid text-center py-3 bg-light border-top">
    Copyright &copy; 2022 - <span class="text-primary fw-bold">Mu'adz Bayu</span>
</footer>
<!-- Akhir Footer -->